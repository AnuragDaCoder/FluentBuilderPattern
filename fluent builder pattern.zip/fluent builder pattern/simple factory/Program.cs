﻿// See https://aka.ms/new-console-template for more information


using static builderPattern.Employee;

var obj = new EmployeeBuilder().WithFirstName("Anurag").WithLastName("Nayak").Build();

Console.WriteLine(obj.ToString());

//you cannot create object of Employee class as its private
//Employee obj1 = new Employee();