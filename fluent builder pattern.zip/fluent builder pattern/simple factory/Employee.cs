﻿

namespace builderPattern
{
    interface IEmployee
    {
        string FirstName { get; }
        string MiddleName { get; }
        string LastName { get; }
    }
    public class Employee : IEmployee
    {
        
        private string firstName;
        private string middleName;
        private string lastName;
        private Employee()
        {

        }

        public override string ToString()
        {
            return FirstName + " " + MiddleName + "" + LastName;
        }
        public string FirstName { get { return firstName; } }

        public string MiddleName => middleName;

        public string LastName => lastName;

        public class EmployeeBuilder
        {
            private readonly Employee _employee;
            public EmployeeBuilder()
            {
                _employee = new Employee();
            }
            public EmployeeBuilder WithFirstName(string firstName)
            {
                _employee.firstName = firstName;
                return this;
            }

            public EmployeeBuilder WithMiddleName(string middleName)
            {
                _employee.middleName = middleName;
                return this;
            }

            public EmployeeBuilder WithLastName(string lastName)
            {
                _employee.lastName = lastName;
                return this;
            }

            public Employee Build()
            {
                return _employee;
            }
        }
    }
}
